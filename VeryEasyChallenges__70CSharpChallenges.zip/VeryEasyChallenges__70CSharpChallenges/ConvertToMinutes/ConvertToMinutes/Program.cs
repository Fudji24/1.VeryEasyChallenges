﻿using System;

namespace ConvertToSeconds
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Choose what you want to convert into seconds: ");
            Console.WriteLine("1. hours \n2.minutes");

            int choice = Convert.ToInt32(Console.ReadLine());
            int seconds;

            if (choice == 1)
            {
                Console.WriteLine("Enter number of hours you want to convert: ");
                int hours = Convert.ToInt32(Console.ReadLine());

                seconds = hours * 60 * 60;
                Console.WriteLine("It has " + seconds + " seconds");
            }
            else if (choice == 2)
            {
                Console.WriteLine("Enter number of minutes you want to convert: ");
                int minutes = Convert.ToInt32(Console.ReadLine());

                seconds = minutes * 60 * 60;
                Console.WriteLine("It has " + seconds + " seconds");
            }
            else
            {
                Console.WriteLine("Your input is not valid!");
            }
            Console.Read();
        }
    }
}
