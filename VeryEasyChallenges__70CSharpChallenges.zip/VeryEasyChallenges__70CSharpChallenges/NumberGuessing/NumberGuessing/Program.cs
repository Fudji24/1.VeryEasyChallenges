﻿using System;

namespace NumberGuessing
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int guessNum = rnd.Next(1, 100);
            bool win = true;
            int tries = 0;

            do
            {

                Console.WriteLine("Guess a number between 1 & 100");
                int userInput = Convert.ToInt32(Console.ReadLine());

                if (userInput > guessNum)
                {
                    tries++;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Guess lower...");
                    Console.ResetColor();
                    win = false;

                    //User can guess 5 times
                    // If there are more than 5 tries, user lose
                    if (tries == 5)
                    {
                        Console.Write("Sorry! You didn't guess. Guessing number was: " + guessNum);
                    }
                }
                else if (userInput < guessNum)
                {
                    tries++;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Guess higher...");
                    Console.ResetColor();
                    win = false;
                    //User can guess 5 times
                    // If there are more than 5 tries, user lose
                    if (tries == 5)
                    {
                        Console.Write("Sorry! You didn't guess. Guessing number was: " + guessNum);
                    }
                }
                else if (userInput == guessNum)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Congratulation! You guessd a number!");
                    Console.ResetColor();
                    win = true;
                }

            } while (win == false);
        }
    }
}
