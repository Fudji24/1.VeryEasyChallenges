﻿using System;

namespace SimpleHoroscope
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of your horoscope: ");
            Console.WriteLine("1.Aquarius;\n2. Pisces;\n3.Aries;\n4.Taurus;\n5.Gemini;\n6.Cancer;\n7.Leo;\n8.Virgo;\n9.Libra;\n10.Scorpio;\n8.Sagittarius;\n9.Capricorn; ");

            int horoscope = Convert.ToInt32(Console.ReadLine());
            //add some extra spaces
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(" ");
            }
            Console.ForegroundColor = ConsoleColor.Green;

            switch (horoscope)
            {
                case 1:
                    Console.WriteLine("Strengths: Progressive, original, independent, humanitarian; \nWeaknesses: Runs from emotional expression, temperamental, uncompromising, aloof");
                    break;
                case 2:
                    Console.WriteLine("Strengths: Compassionate, artistic, intuitive, gentle, wise, musical; \nWeaknesses: Fearful, overly trusting, sad, desire to escape reality, can be a victim or a martyr");
                    break;
                case 3:
                    Console.WriteLine("Strengths: courageous, determined, confident, enthusiastic, optimistic, honest; \nWeaknesses: impatient, moody, short - tempered, impulsive, aggressive");
                    break;
                case 4:
                    Console.WriteLine("Strengths: reliable, patient, practical, devoted, responsible; \nWeaknesses: stubborn, possessive, uncompromising");
                    break;
                case 5:
                    Console.WriteLine("Strengths: gentle, affectionate, curious, adaptable, ability to learn quickly and exchange; \nWeaknesses: nervous, inconsistent, indecisive");
                    break;
                case 6:
                    Console.WriteLine("Strengths: tenacious, highly imaginative, loyal, emotional, sympathetic; \nWeaknesses: moody, pessimistic, suspicious, manipulative, insecure");
                    break;
                case 7:
                    Console.WriteLine("Strengths: creative, passionate, generous, warm-hearted, cheerful; \nWeaknesses: arrogant, stubborn, self - centered, lazy, inflexible");
                    break;
                case 8:
                    Console.WriteLine("Strengths: loyal, analytical, kind, hardworking, practical; \nWeaknesses: shyness, worry, overly critical of self and others, all work and no play");
                    break;
                case 9:
                    Console.WriteLine("Strengths: cooperative, diplomatic, gracious, fair-minded, social; \nWeaknesses: indecisive, avoids confrontations, will carry a grudge, self - pity");
                    break;
                case 10:
                    Console.WriteLine("Strengths: resourceful, brave, passionate, stubborn, a true friend; \nWeaknesses: distrusting, jealous, secretive, violent");
                    break;
                case 11:
                    Console.WriteLine("Strengths: generous, idealistic, great sense of humor; \nWeaknesses: promises more than can deliver, very impatient, will say anything no matter how undiplomatic");
                    break;
                case 12:
                    Console.WriteLine("Strengths: responsible, disciplined, self-control, good managers; \nWeaknesses: know - it - all, unforgiving, condescending, expecting the worst");
                    break;


                default:
                    break;
            }

            Console.Read();
        }
    }
}
