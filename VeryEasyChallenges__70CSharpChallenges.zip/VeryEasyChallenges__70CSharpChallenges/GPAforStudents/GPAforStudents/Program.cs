﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GPAforStudents
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How many grades do you have? ");

            int gradesNum = Convert.ToInt32(Console.ReadLine());
            List<int> gradesList = new List<int>();

            for (int i = 0; i < gradesNum; i++)
            {
                Console.WriteLine("Insert grade: ");
                int grade = Convert.ToInt32(Console.ReadLine());

                gradesList.Add(grade);
            }

            double gradesSum = gradesList.Sum();
            double gpa = gradesSum / gradesNum;

            Console.WriteLine("Your GPA is: " + gpa);

            Console.ReadLine();
        }
    }
}
