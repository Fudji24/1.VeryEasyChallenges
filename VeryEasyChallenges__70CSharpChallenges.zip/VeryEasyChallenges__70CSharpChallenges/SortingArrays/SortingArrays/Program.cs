﻿using System;
using System.Linq;

namespace SortingArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            //let's make string array
            //I made a list of random cities for this task

            string[] strArr = { "Washington", "Atena", "Berlin", "Rome", "Amsterdam", "Paris", "New York", "Quebec", "Istanbul", "Moscow", "Madrid", "Kiev", "Buenos Aires", "Delhi" };
            //use a method for sorting strings
            Array.Sort(strArr);

            foreach (var item in strArr)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine("\n");
            //make a int array of random numbers
            Random rnd = new Random();
            int[] intArr = Enumerable.Repeat(0, 20).Select(x => rnd.Next(0, 100)).ToArray();

            //sort int numbers
            Array.Sort(intArr);

            foreach (var item in intArr)
            {
                Console.Write(item + " ");
            }

            Console.Read();
            
        }
    }
}
