﻿using System;
using System.Text;

namespace PasswordGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            const string passChar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!?*-+:";
            StringBuilder password = new StringBuilder();
            Random rnd = new Random();
            Console.Write("How long do you want your password to be? ");
            int length = Convert.ToInt32(Console.ReadLine());

            while (0 < length -- )
            {
                password.Append(passChar[rnd.Next(passChar.Length)]);
            }

            Console.WriteLine("Your password: " + password);
            Console.ReadLine();
        }
    }
}
