﻿using System;
using System.Text;

namespace ScoobyDoo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write a word or a sentence you want to be Scooby-Doo: ");
            string sentence = Console.ReadLine();

            if (sentence.StartsWith('a') || sentence.StartsWith('e') || sentence.StartsWith('i') || sentence.StartsWith('o') || sentence.StartsWith('u'))
            {
                Console.WriteLine(sentence);
                Console.ReadLine();
            }
            else
            {
                sentence.Remove(0);
                StringBuilder newSentence = new StringBuilder(sentence);
                newSentence[0] = 'r';
                Console.WriteLine(newSentence);
                Console.ReadLine();
            }
            
        }
    }
}
