﻿using System;

namespace WhatDayWas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insert a date (format is: 'MM-dd-yyyy'): ");
            Console.WriteLine("If you want to stop application enter 'C' on your keyboard");

            //we want to allow user to repeat proccess
            do
            {
                //adding try-catch if user insert another date format
                try
                {
                    DateTime userDate = Convert.ToDateTime(Console.ReadLine());

                    Console.WriteLine(userDate.DayOfWeek);
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(ex);
                    Console.WriteLine("Check input!");
                    Console.ResetColor();
                }
            } while (Console.ReadKey(true).Key != ConsoleKey.C);
        }
    }
}
