﻿using System;
using System.Linq;

namespace CountVowels
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Write a sentence:");
            string sentence = Console.ReadLine();

            int vowelCount = sentence.Count(x => "aeiou".Contains(Char.ToLower(x)));

            Console.WriteLine("Number of vowels in your sentence is: " + vowelCount);
        }
    }
}
