﻿using System;
using System.Linq;

namespace LottoNumberGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            var rnd = new Random();
            //let's make more interesant
            //add possibility for user to enter number of combinations
            Console.WriteLine("Enter number of combination you want to generate: ");
            int combinations = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < combinations; i++)
            {
                var randomNumbers = Enumerable.Range(1, 49).OrderBy(x => rnd.Next()).Take(6).ToList();

                foreach (var item in randomNumbers)
                {
                    Console.Write(item + " ");
                }
                Console.WriteLine("\n");
            }

            

            Console.Read();
        }
    }
}
