﻿using System;

namespace AreaSquareCircleTriangleRectangle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Choose a shape: ");
            Console.WriteLine("1.Circle;\n2.Square;\n3.Triangle;\n4.Rectangle;");

            Console.WriteLine("Insert number of shape: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            if (choice == 1)
            {
                //area of circle is r*r*pi

                Console.WriteLine("Insert radius value: ");
                double radius = Convert.ToDouble(Console.ReadLine());
                if (radius > 0)
                {
                    double area = radius * radius * Math.PI;
                    Console.WriteLine("Area of your circle is: " + area);
                }
                else
                {
                    Console.WriteLine("Radius can't be equal or less than zero!");
                }
            }
            else if (choice == 2)
            {
                //area of square is a*a
                Console.WriteLine("Insert value of square's side");
                double sqSide = Convert.ToDouble(Console.ReadLine());

                if (sqSide > 0)
                {
                    double sqArea = sqSide * sqSide;
                    Console.WriteLine("Area of your square is: " + sqArea);
                }
                else
                {
                    Console.WriteLine("Sqare side can't be equal or less then zero");
                }
            }
            else if (choice == 3)
            {
                //area of triangle is a*b / 2
                Console.WriteLine("Insert value of first side: ");
                double firstSide = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Insert value of second side: ");
                double secondSide = Convert.ToDouble(Console.ReadLine());

                if (firstSide > 0 && secondSide > 0)
                {
                    double trArea = firstSide * secondSide / 2;
                    Console.WriteLine("Area of your triangle is: " + trArea);
                }
                else
                {
                    Console.WriteLine("Sides are not positive value. Please check input.");
                }
            }
            else if (choice == 4)
            {
                //area of rectangle is a*b
                Console.WriteLine("Insert value of first side: ");
                double a = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Insert value of second side: ");
                double b = Convert.ToDouble(Console.ReadLine());

                if (a> 0 && b > 0)
                {
                    double recArea = a * b;
                    Console.WriteLine("Area of your rectangle is: " + recArea);
                }
                else
                {
                    Console.WriteLine("Values are not positive. Check input!");
                }
            }
            else
            {
                Console.WriteLine("Wrong input!");
            }

            Console.ReadLine();
        }
    }
}
