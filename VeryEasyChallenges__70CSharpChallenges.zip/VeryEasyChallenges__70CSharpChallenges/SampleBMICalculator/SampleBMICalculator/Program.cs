﻿using System;

namespace SampleBMICalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your weight in kg: ");
            decimal weight = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Enter your height in cm: ");
            decimal height = Convert.ToDecimal(Console.ReadLine());


            //Formula for BMI is: [weight / height] / height * 10 000
            decimal weightHeight = weight / height;
            decimal firstPart = weightHeight / height;
            decimal fullFormula = firstPart * 10000;

            Console.WriteLine("Your BMI is: " + Math.Round(fullFormula, 2));

            //clasification
            //clasification taken from: https://hr.wikipedia.org/wiki/Indeks_tjelesne_mase#BMI_klasifikacija
            if (fullFormula < 20)
            {
                Console.WriteLine("You are: Malnutrition");
            }
            else if (fullFormula >=20 && fullFormula <=25)
            {
                Console.WriteLine("You are: Ideal weight");
            }
            else if (fullFormula > 25 && fullFormula < 30)
            {
                Console.WriteLine("You are: Overweight");
            }
            else if (fullFormula >=30)
            {
                Console.WriteLine("You are: Obesity");
            }

            Console.ReadLine();

        }
    }
}
