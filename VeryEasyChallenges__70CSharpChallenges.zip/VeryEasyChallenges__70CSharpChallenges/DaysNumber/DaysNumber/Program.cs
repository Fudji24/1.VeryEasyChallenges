﻿using System;

namespace DaysNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a date (format is 'mm/dd/yyyy'): ");
            DateTime date = Convert.ToDateTime(Console.ReadLine());
            DateTime nowDate = DateTime.Now;
            TimeSpan difference = date - nowDate;
            double days = difference.TotalDays;
            


            Console.WriteLine(Convert.ToInt32(days));
        }
    }
}
